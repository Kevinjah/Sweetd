package com.example.sweetdataapp
import android.content.Context
import com.wireguard.android.backend.Tunnel
import com.wireguard.android.backend.TunnelManager
import com.wireguard.android.config.Config
import com.wireguard.android.config.ConfigParser
class WireGuardManager(private val context: Context) {
    private val manager = TunnelManager.getInstance(context)
    fun startTunnel(configString: String, tunnelName: String = "sweetdata") {
        val config: Config = ConfigParser().parseConfig(configString)
        val tunnel: Tunnel = manager.create(tunnelName, config)
        tunnel.up()
    }
    fun stopTunnel(tunnelName: String = "sweetdata") {
        val tunnel = manager[tunnelName]
        tunnel?.down()
    }
}
