package com.example.sweetdataapp
import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
class MainActivity : AppCompatActivity() {
    private lateinit var wgManager: WireGuardManager
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wgManager = WireGuardManager(this)
        val webView = findViewById<WebView>(R.id.webView)
        webView.webViewClient = WebViewClient()
        webView.settings.javaScriptEnabled = true
        webView.loadUrl("[https://sweetdata.cam](https://sweetdata.cam)")
        val wgConfig = """
            [Interface]
            PrivateKey = GIemWyVyUJqrvKSZh4woOw+wRpg1vEwXbw4vlxEHBHQ=
            Address = 10.8.0.2/32
            DNS = 1.1.1.1, 8.8.8.8
            [Peer]
            PublicKey = cc8kKCEg8HcnoTXt/4UUfMjHuMFyaF7157Tem7Umm mE=
            AllowedIPs = 0.0.0.0/1, 128.0.0.0/1
            Endpoint = 161.35.76.106:51820
            PersistentKeepalive = 25
        """.trimIndent()
        findViewById<Button>(R.id.btnActivate).setOnClickListener {
            wgManager.startTunnel(wgConfig)
        }
        findViewById<Button>(R.id.btnDeactivate).setOnClickListener {
            wgManager.stopTunnel()
        }
    }
}
